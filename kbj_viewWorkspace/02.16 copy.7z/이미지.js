class Img {
    constructor() {
        this.treeImg = new Image();
        this.treeImg.src = 'animal_labbit.gif';
    }

}